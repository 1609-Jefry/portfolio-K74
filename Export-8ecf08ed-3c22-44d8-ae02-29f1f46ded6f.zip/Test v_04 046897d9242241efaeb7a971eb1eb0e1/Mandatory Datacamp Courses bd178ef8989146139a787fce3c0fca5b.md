# Mandatory Datacamp Courses

![Mandatory%20Datacamp%20Courses%20bd178ef8989146139a787fce3c0fca5b/Untitled.png](Mandatory%20Datacamp%20Courses%20bd178ef8989146139a787fce3c0fca5b/Untitled.png)

# Certificates:

---

[introductionToPython.pdf](Mandatory%20Datacamp%20Courses%20bd178ef8989146139a787fce3c0fca5b/introductionToPython.pdf)

[IntermediatePython.pdf](Mandatory%20Datacamp%20Courses%20bd178ef8989146139a787fce3c0fca5b/IntermediatePython.pdf)

[Python Data Science Toolbox (Part 1).pdf](Mandatory%20Datacamp%20Courses%20bd178ef8989146139a787fce3c0fca5b/Python_Data_Science_Toolbox_(Part_1).pdf)

[Python Data Science Toolbox (Part 2).pdf](Mandatory%20Datacamp%20Courses%20bd178ef8989146139a787fce3c0fca5b/Python_Data_Science_Toolbox_(Part_2).pdf)

[pandas Foundations.pdf](Mandatory%20Datacamp%20Courses%20bd178ef8989146139a787fce3c0fca5b/pandas_Foundations.pdf)

[Introduction to Data Visualization.pdf](Mandatory%20Datacamp%20Courses%20bd178ef8989146139a787fce3c0fca5b/Introduction_to_Data_Visualization_in_Python.pdf)

[Manipulating DataFrames with Pandas.pdf](Mandatory%20Datacamp%20Courses%20bd178ef8989146139a787fce3c0fca5b/Manipulating_DataFrames_with_Pandas.pdf)

[Data Types for Data Science in Python.pdf](Mandatory%20Datacamp%20Courses%20bd178ef8989146139a787fce3c0fca5b/Data_Types_for_Data_Science_in_Python.pdf)

[Cleaning Data in Python.pdf](Mandatory%20Datacamp%20Courses%20bd178ef8989146139a787fce3c0fca5b/Cleaning_Data_in_Python.pdf)

[Preprocessing for Machine Learning.pdf](Mandatory%20Datacamp%20Courses%20bd178ef8989146139a787fce3c0fca5b/Preprocessing_for_Machine_Learning_in_Python.pdf)