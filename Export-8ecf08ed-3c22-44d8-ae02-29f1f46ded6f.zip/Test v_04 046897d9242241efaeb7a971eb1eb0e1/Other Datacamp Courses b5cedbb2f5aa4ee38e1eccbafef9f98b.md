# Other Datacamp Courses

We were doing a lot of data pre-processing and we were working with time-series. This is why we chose together with the team to do some additional courses to get a better feel for data science. And also to prevent hours of searching for easily solvable problems in basic steps.

# Certificates:

---

[Merging DataFrames with pandas.pdf](Other%20Datacamp%20Courses%20b5cedbb2f5aa4ee38e1eccbafef9f98b/Merging_DataFrames_with_pandas.pdf)

[Exploratory Data Analysis in Python.pdf](Other%20Datacamp%20Courses%20b5cedbb2f5aa4ee38e1eccbafef9f98b/Exploratory_Data_Analysis_in_Python.pdf)