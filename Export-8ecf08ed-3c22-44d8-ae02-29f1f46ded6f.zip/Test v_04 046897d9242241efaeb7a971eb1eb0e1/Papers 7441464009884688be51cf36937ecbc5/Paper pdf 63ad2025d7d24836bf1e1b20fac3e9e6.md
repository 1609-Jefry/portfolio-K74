# Paper pdf

[Short-term energy use prediction of solar-assisted.pdf](Paper%20pdf%2063ad2025d7d24836bf1e1b20fac3e9e6/Heidari_and_Khovalyg_-_2020_-_Short-term_energy_use_prediction_of_solar-assisted.pdf)